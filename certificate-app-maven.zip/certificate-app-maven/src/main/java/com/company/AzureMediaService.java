package com.company;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;
import java.util.EnumSet;
import java.util.List;

import com.microsoft.windowsazure.services.core.Configuration;
import com.microsoft.windowsazure.services.blob.client.*;
//import com.microsoft.windowsazure.services.core.Configuration;
import com.microsoft.windowsazure.services.core.ServiceException;
import com.microsoft.windowsazure.services.core.storage.StorageException;
import com.microsoft.windowsazure.services.media.*;
import com.microsoft.windowsazure.services.media.models.*;



/**
 * @see com.gistech.common.AzureMediaService 微软媒体服务，提供视频上传和下载
 * @author zhangdc
 * 
 */
public class AzureMediaService {
	 private static MediaContract mediaService;
	 private static AssetInfo assetToEncode, encodedAsset;

	 public static void Init() throws ServiceException 
	    {
	        String mediaServiceUri = "https://wamsshaclus001rest-hs.chinacloudapp.cn/API/";//"https://media.windows.net/API/";
	        String oAuthUri = "https://wamsprodglobal001acs.accesscontrol.chinacloudapi.cn/v2/OAuth2-13";//"https://wamsprodglobal001acs.accesscontrol.windows.net/v2/OAuth2-13";
	        String clientId = "mediaflowtest";  // Use your media service account name.
	        String clientSecret = "2xhASWOh03yqMnpki4xQphykEYFt2rdJ9JJ5h5zn2iM="; // Use your media service access key. 
	        String scope = "urn:WindowsAzureMediaServices";

	        // Specify the configuration values to use with the MediaContract object.
	        Configuration configuration =  MediaConfiguration
	                .configureWithOAuthAuthentication(mediaServiceUri, oAuthUri, clientId, clientSecret, scope);

	        // Create the MediaContract object using the specified configuration.
	        mediaService = MediaService.create(configuration);

	    }


	 
	 public static void Upload() throws ServiceException, FileNotFoundException, NoSuchAlgorithmException, com.microsoft.windowsazure.exception.ServiceException 
	 {

	        WritableBlobContainerContract uploader;

	        AccessPolicyInfo uploadAccessPolicy;
	        LocatorInfo uploadLocator = null;

	        // Create an asset.
	        //assetToEncode = mediaService.create(Asset.create().setName("v5-540").setAlternateId("altId"));
	       
	        assetToEncode = mediaService.create(Asset.create()
	                .setName("v5-540").setOptions(AssetOption.None));
	        
	        System.out.println("Created asset with id: " + assetToEncode.getId());

	        // Create an access policy that provides Write access for 15 minutes.
	        uploadAccessPolicy = mediaService.create(AccessPolicy.create("writable", 
	                                                                     15.0, 
	                                                                     EnumSet.of(AccessPolicyPermission.WRITE)));
	        System.out.println("Created upload access policy with id: "
	                + uploadAccessPolicy.getId());

	        // Create a locator using the access policy and asset.
	        // This will provide the location information needed to add files to the asset.
	        uploadLocator = mediaService.create(Locator.create(uploadAccessPolicy.getId(),
	                assetToEncode.getId(), LocatorType.SAS));
	        System.out.println("Created upload locator with id: " + uploadLocator.getId());

	        // Create the blob writer using the locator.
	        uploader = mediaService.createBlobWriter(uploadLocator);

	        // The name of the file as it will exist in your Media Services account.
	        String fileName = "v5-540.mp4";  

	        // The local file that will be uploaded to your Media Services account.
	        InputStream input = new FileInputStream(new File("E:/Work/MGIS/" + fileName));

	        // Upload the local file to the asset.
	        uploader.createBlockBlob(fileName, input);

	        // Inform Media Services about the uploaded files.
	        mediaService.action(AssetFile.createFileInfos(assetToEncode.getId()));
	        System.out.println("File uploaded.");


	        System.out.println("Deleting upload locator and access policy.");
	        mediaService.delete(Locator.delete(uploadLocator.getId()));
	        mediaService.delete(AccessPolicy.delete(uploadAccessPolicy.getId()));

	    }
	 
	 public static void Download() throws ServiceException, URISyntaxException, FileNotFoundException, StorageException, IOException, com.microsoft.windowsazure.exception.ServiceException 
	 {

	        AccessPolicyInfo downloadAccessPolicy = null;

	        downloadAccessPolicy =
	                mediaService.create(AccessPolicy.create("Download", 15.0, EnumSet.of(AccessPolicyPermission.READ)));
	        System.out.println("Created download access policy with id: "
	                + downloadAccessPolicy.getId());

	        LocatorInfo downloadLocator = null;
	        downloadLocator = mediaService.create(
	                Locator.create(downloadAccessPolicy.getId(), encodedAsset.getId(), LocatorType.SAS));
	        System.out.println("Created download locator with id: " + downloadLocator.getId());        

	        System.out.println("Accessing the output files of the encoded asset.");
	        // Iterate through the files associated with the encoded asset.
	        for(AssetFileInfo assetFile: mediaService.list(AssetFile.list(encodedAsset.getAssetFilesLink())))
	        {
	            String fileName = assetFile.getName();

	            System.out.print("Downloading file: " + fileName + ". ");
	            String locatorPath = downloadLocator.getPath();
	            int startOfSas = locatorPath.indexOf("?");

	            String blobPath = locatorPath + fileName;
	            if (startOfSas >= 0) 
	            {
	                blobPath = locatorPath.substring(0, startOfSas) + "/" + fileName + locatorPath.substring(startOfSas);
	            }
	            URI baseuri = new URI(blobPath);
	            CloudBlobClient blobClient;
	            blobClient = new CloudBlobClient(baseuri);

	            // Ensure that you have a c:\output folder, or modify the path specified in the following statement.
	            String localFileName = "c:/output/" + fileName;

	            CloudBlockBlob sasBlob;
	            sasBlob = new CloudBlockBlob(baseuri, blobClient);
	            File fileTarget = new File(localFileName);

	            sasBlob.download(new FileOutputStream(fileTarget));
	            System.out.println("Download complete.");

	        }

	        System.out.println("Deleting download locator and access policy.");
	        mediaService.delete(Locator.delete(downloadLocator.getId()));
	        mediaService.delete(AccessPolicy.delete(downloadAccessPolicy.getId()));

	    }


}
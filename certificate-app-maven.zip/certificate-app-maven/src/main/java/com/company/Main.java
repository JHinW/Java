package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.setProperty("javax.net.ssl.trustStore","E:\\GitHub\\work\\javaE2etest\\certicate-test\\jssecacerts");
        try{
            AzureMediaService.Init();
            AzureMediaService.Upload();

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
